for i in range(1,11):
    for j in range(1,11):
        print("|",i*j, end=' \t')
    print(chr(9475))
input("Press any key to continue...")